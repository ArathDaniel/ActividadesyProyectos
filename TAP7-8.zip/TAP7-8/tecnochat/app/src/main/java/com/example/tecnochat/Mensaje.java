package com.example.tecnochat;

public class Mensaje {
    String usuario;
    int tipo;
    String mensaje;
    String remitente;
}